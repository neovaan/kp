<?php
class InheritedTestCase extends OneTestCase
{
    public function test2()
    {
    }
}
